-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2026 at 12:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gold_shop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `image` text DEFAULT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `featured` tinyint(1) DEFAULT 0,
  `subcategories` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_id`, `name`, `description`, `image`, `status`, `featured`, `subcategories`, `created_at`, `updated_at`) VALUES
(7, 'CAT001', 'Good', 'Good', '/public/category-images/category-1780992679741-937189443.png', 'Active', 1, '[\"Men\'s Ring\",\"Women\'s Ring\",\"Engagement Ring\",\"Wedding Ring\"]', '2026-06-09 02:41:19', '2026-06-09 02:41:19');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `sub_category` varchar(100) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `purity` varchar(50) DEFAULT NULL,
  `hallmark` tinyint(1) DEFAULT 0,
  `certificate` varchar(100) DEFAULT NULL,
  `weight` decimal(10,3) DEFAULT NULL,
  `weight_unit` varchar(20) DEFAULT NULL,
  `coin_weight` varchar(50) DEFAULT NULL,
  `making_charges` decimal(10,2) DEFAULT NULL,
  `wastage_percentage` decimal(5,2) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `offer_price` decimal(10,2) DEFAULT NULL,
  `discount` decimal(5,2) DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `sku` varchar(100) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `occasion` text DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `material` varchar(50) DEFAULT NULL,
  `size` text DEFAULT NULL,
  `length_options` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `features` text DEFAULT NULL,
  `dimensions` text DEFAULT NULL,
  `shipping` text DEFAULT NULL,
  `return_policy` text DEFAULT NULL,
  `seo` text DEFAULT NULL,
  `images` text DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Active',
  `featured` tinyint(1) DEFAULT 0,
  `best_seller` tinyint(1) DEFAULT 0,
  `new_arrival` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_id`, `name`, `category`, `sub_category`, `brand`, `purity`, `hallmark`, `certificate`, `weight`, `weight_unit`, `coin_weight`, `making_charges`, `wastage_percentage`, `price`, `offer_price`, `discount`, `stock`, `sku`, `gender`, `occasion`, `color`, `material`, `size`, `length_options`, `description`, `features`, `dimensions`, `shipping`, `return_policy`, `seo`, `images`, `status`, `featured`, `best_seller`, `new_arrival`, `created_at`, `updated_at`) VALUES
(1, 'GLD3678', 'New', 'Good', 'Women\'s Ring', 'Royal Gold Jewellers', '22K', 1, 'BIS Hallmarked', 500.000, 'grams', NULL, 1000.00, 10.00, 10000.00, 9000.00, 10.00, 500, 'EO-1L', 'Male', '[\"Daily Wear\",\"Wedding\",\"Festival\"]', 'Yellow Gold', 'Gold', '[10,12,14,16,18,20]', '[\"18 Inch\",\"20 Inch\",\"22 Inch\",\"24 Inch\"]', 'gfhfghf', '[\"22K Pure Gold\",\"BIS Hallmarked\",\"Premium Finish\"]', '{\"length\":\"\",\"width\":\"\"}', '{\"freeShipping\":true,\"estimatedDelivery\":\"3-5 Days\",\"cashOnDelivery\":false}', '{\"returnAvailable\":true,\"returnDays\":7}', '{\"metaTitle\":\"\",\"metaDescription\":\"\",\"keywords\":[\"gold\",\"jewellery\"]}', '[\"/public/product-images/product-1780993836664-764700917.png\",\"/public/product-images/product-1780993836670-817817330.png\",\"/public/product-images/product-1780993836677-561119272.png\",\"/public/product-images/product-1780993836681-319854624.png\",\"/public/product-images/product-1780993836682-343330447.png\"]', 'Active', 1, 1, 1, '2026-06-09 08:18:37', '2026-06-09 08:35:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `role` varchar(20) DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `username`, `email`, `phone`, `password_hash`, `status`, `created_at`, `updated_at`, `role`) VALUES
(1, 'test-uuid-123', 'testuser', 'test@example.com', '1234567890', '$2a$10$jehUjlGhmuaLqCtporav7OjfMbEX6NpiOGl7Hxqjm12LRy9T8u7c.', 'active', '2026-06-09 05:51:24', '2026-06-09 05:51:24', 'user'),
(2, '728081d9-03b0-4048-b1bb-ca99079fd81d', 'Dhivakar', 'dhivakarp305@gmail.com', '9865359464', '$2a$10$gSLBRX99m7p7JprtaINbfu2z6nY85/dk2okDspEDDArBti0zjn7ne', 'active', '2026-06-09 05:51:31', '2026-06-09 05:51:31', 'user'),
(3, '1e90f290-3f33-489b-bbbf-06486212a0d2', 'admin', 'admin@gmail.com', '', '$2a$10$rP4T.4RJjev8j2X9sjCjC.b50o3AyFiMRKbcCMArGgYApf9Vch1gW', 'active', '2026-06-09 06:02:59', '2026-06-09 06:02:59', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_id` (`category_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
