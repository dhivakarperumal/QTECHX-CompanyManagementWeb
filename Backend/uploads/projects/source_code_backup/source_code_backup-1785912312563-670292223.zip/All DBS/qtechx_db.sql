-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2026 at 10:35 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qtechx_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('Super Admin','Admin','Manager','Staff','Employee','Customer','User') NOT NULL DEFAULT 'Customer',
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `username`, `email`, `mobile`, `password`, `role`, `status`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, 'a221f2de-8668-11f1-8f5e-2bc0420863d7', 'Admin', 'admin@gmail.com', '1234567890', '$2b$12$rnPJuOo9oWCfet3x2gYAvel6zEYKR/wm9plrxoFBo16WNfwO7xd6K', 'Super Admin', 'Active', '2026-07-23 07:32:18', '2026-07-23 07:32:18', 'SYSTEM', 'SYSTEM'),
(2, 'b6a943a4-7443-4800-8f39-4ec643f2ad83', 'emp', 'emp@gmail.com', '1234567899', '$2b$12$T2WN967WxMtUWDKnhBv4Vu4QdLjmHHZLiXJlS8AJxjfEWvDo.J33S', 'Employee', 'Active', '2026-07-23 07:52:31', '2026-07-23 07:53:13', 'SYSTEM', 'SYSTEM'),
(3, 'bb6b214b-a922-42ad-80f0-786f699ae9be', 'user', 'user@gmail.com', '1234567888', '$2b$12$Vj41PgEsbZwnVfCKjFAnT.uWd/x5jPmzRld3672k37HTlrEsOzYBW', 'User', 'Active', '2026-07-23 07:59:32', '2026-07-23 07:59:32', 'SYSTEM', 'SYSTEM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
